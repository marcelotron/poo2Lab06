
package MercadoFinanceiro;


public interface StockSubject {
    void registerObserver(InvestorObserver observer);
    void removeObserver(InvestorObserver observer);
    void notifyObservers();
}