package MercadoFinanceiro;

public interface InvestorObserver {
    void update(Stock stock);
}
