
package MercadoFinanceiro;


public class Main {
    public static void main(String[] args) {
        Stock stock = new Stock(100);
        Investor investor1 = new Investor("Investidor 1", 90, 110);
        Investor investor2 = new Investor("Investidor 2", 95, 105);

        stock.registerObserver(investor1);
        stock.registerObserver(investor2);

        stock.setPrice(110); 
    }
}
