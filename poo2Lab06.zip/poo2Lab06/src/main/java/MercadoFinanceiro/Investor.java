
package MercadoFinanceiro;


public class Investor implements InvestorObserver {
    private String name;
    private double minPrice;
    private double maxPrice;

    public Investor(String name, double minPrice, double maxPrice) {
        this.name = name;
        this.minPrice = minPrice;
        this.maxPrice = maxPrice;
    }

    @Override
    public void update(Stock stock) {
        if (stock.getPrice() >= maxPrice) {
            System.out.println(name + " vende a ação " + stock.getPrice());
        }
    }
}
