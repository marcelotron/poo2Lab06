
package MercadoFinanceiro;

import java.util.ArrayList;
import java.util.List;

public class Stock implements StockSubject {
    private List<InvestorObserver> observers;
    private double price;

    public Stock(double price) {
        this.price = price;
        this.observers = new ArrayList<>();
    }

    @Override
    public void registerObserver(InvestorObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(InvestorObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (InvestorObserver observer : observers) {
            observer.update(this);
        }
    }

    public void setPrice(double price) {
        this.price = price;
        notifyObservers();
    }

    public double getPrice() {
        return price;
    }
}