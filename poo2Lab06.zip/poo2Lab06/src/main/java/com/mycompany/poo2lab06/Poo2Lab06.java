

package com.mycompany.poo2lab06;


public class Poo2Lab06 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
