
package CET;


public class Aeroporto implements Observer {
    private float rajadasDeVento;

    @Override
    public void update(float temperatura, float umidade, float rajadasDeVento) {
        this.rajadasDeVento = rajadasDeVento;
        exibirInformacoesRajadasVento();
    }

    public void exibirInformacoesRajadasVento() {
     
        System.out.println("Informações de rajadas de vento: " + rajadasDeVento);
    }
}


