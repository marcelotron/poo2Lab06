
package CET;
import java.util.ArrayList;
import java.util.List;


public class Cet implements Subject {
    
    private List<Observer> observers;
    private float temperatura;
    private float umidade;
    private float rajadasDeVento;

    public Cet() {
        observers = new ArrayList<>();
    }

    public void setMedicoes(float temperatura, float umidade, float rajadasDeVento) {
        this.temperatura = temperatura;
        this.umidade = umidade;
        this.rajadasDeVento = rajadasDeVento;
        notifyObservers();
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(temperatura, umidade, rajadasDeVento);
        }
    }
}

 


