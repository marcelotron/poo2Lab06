
package CET;


public interface Observer {
   public void update(float temperatura, float umidade, float rajadasDeVento);
}
