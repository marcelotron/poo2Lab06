
package CET;


public class Prefeitura implements Observer {
    private float umidade;

    @Override
    public void update(float temperatura, float umidade, float rajadasDeVento) {
        this.umidade = umidade;
        emitirAlertaDefesaCivil();
    }

    public void emitirAlertaDefesaCivil() {

        System.out.println("Alerta da Defesa Civil - Umidade relativa do ar: " + umidade);
    }
} 
    

