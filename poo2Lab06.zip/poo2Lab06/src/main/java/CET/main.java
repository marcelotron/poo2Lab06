
package CET;


 public class main {
    public static void main(String[] args) {
       
        Cet cet = new Cet();

        
        Prefeitura prefeitura = new Prefeitura();
        Aeroporto aeroporto = new Aeroporto();

       
        cet.registerObserver(prefeitura);
        cet.registerObserver(aeroporto);

        
        cet.setMedicoes(25.5f, 60.2f, 30.0f);
    }
}